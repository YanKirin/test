define(function(){
    return {
        pageGroups: [{"id":"58d2ae72-7241-fcf6-c43a-770dc2e96b1e","name":"WOW","pages":[{"id":"25505cf6-a6c9-f31a-1d0d-c97523968213","name":"Главная"},{"id":"c115320e-f1f1-9e95-b731-d7dda06fc688","name":"Магазины"},{"id":"39d23f5e-0406-7acf-c8bc-0a0566dd6576","name":"Sig In"},{"id":"2796ebee-3b81-e3c4-9dc5-1bd8a30f6f85","name":"How it work"},{"id":"c4218ec2-9079-80c3-a0cd-7920f82b6a3d","name":"Партнерам"},{"id":"4c5365f2-f732-d157-712f-c16e2739d5fb","name":"App"},{"id":"c6100f1c-fcbe-d079-2131-0c6825891df2","name":"Регистрация"},{"id":"e783eea0-a59f-c9ab-75f6-bebcae079667","name":"Форма подачи заявки"},{"id":"9cb5d93a-f4eb-5e94-f885-5d001ae2577a","name":"Профиль отзыв"},{"id":"217c1ddc-d152-c1cb-8b3a-017595e8cd40","name":"Профиль магазина"}]}],
        downloadLink: "//services.ninjamock.com/html/htmlExport/download?shareCode=27KSC&projectName=WOW",
        startupPageId: 0,

        forEachPage: function(func, thisArg){
        	for (var i = 0, l = this.pageGroups.length; i < l; ++i){
                var group = this.pageGroups[i];
                for (var j = 0, k = group.pages.length; j < k; ++j){
                    var page = group.pages[j];
                    if (func.call(thisArg, page) === false){
                    	return;
                    }
                }
            }
        },
        findPageById: function(pageId){
        	var result;
        	this.forEachPage(function(page){
        		if (page.id === pageId){
        			result = page;
        			return false;
        		}
        	});
        	return result;
        }
    }
});
